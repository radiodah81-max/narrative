package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Part
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatInputArea(
    isGenerating: Boolean,
    messageCount: Int,
    messageLimit: Int,
    onSend: (String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    val isNearLimit = messageCount >= (messageLimit * 0.8)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceLight)
            .border(width = 1.dp, color = BorderLight)
            .padding(16.dp)
            .navigationBarsPadding()
            .imePadding()
    ) {
        if (isNearLimit) {
            Text(
                text = "اقتربت من حد الرسائل ($messageCount / $messageLimit). سينشئ جزء جديد تلقائيًا.",
                color = AccentColor,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("اكتب رسالتك...", color = SecondaryTextLight) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = BackgroundLight,
                    unfocusedContainerColor = BackgroundLight,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent
                ),
                shape = RoundedCornerShape(24.dp),
                maxLines = 4,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
            )
            Spacer(modifier = Modifier.width(12.dp))
            IconButton(
                onClick = {
                    if (text.isNotBlank() && !isGenerating) {
                        onSend(text)
                        text = ""
                    }
                },
                enabled = text.isNotBlank() && !isGenerating,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (text.isNotBlank() && !isGenerating) AccentColor else BorderLight)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال", tint = SurfaceLight)
            }
        }
        
        Text(
            text = "$messageCount / $messageLimit رسالة في هذا الجزء",
            color = SecondaryTextLight,
            fontSize = 10.sp,
            modifier = Modifier.padding(top = 8.dp).align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
fun SidebarContent(
    parts: List<Part>,
    activePartId: Int?,
    onPartSelect: (Int) -> Unit,
    onNewPartClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    ModalDrawerSheet(
        drawerContainerColor = SurfaceLight,
        modifier = Modifier.width(300.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text("الأجزاء", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = PrimaryTextLight)
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onNewPartClick,
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor, contentColor = SurfaceLight),
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("محادثة جديدة")
            }
            Spacer(modifier = Modifier.height(16.dp))
            
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(parts) { part ->
                    val isActive = part.id == activePartId
                    val bgColor = if (isActive) AIBubbleBackground else Color.Transparent
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(bgColor)
                            .clickable { onPartSelect(part.id) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(part.title, fontWeight = FontWeight.SemiBold, color = PrimaryTextLight)
                            if (part.summary != null) {
                                Text("ملخص متاح", fontSize = 12.sp, color = AccentColor)
                            }
                        }
                    }
                }
            }
            
            HorizontalDivider(color = BorderLight, modifier = Modifier.padding(vertical = 16.dp))
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSettingsClick() }
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Settings, contentDescription = null, tint = SecondaryTextLight)
                Spacer(modifier = Modifier.width(16.dp))
                Text("الإعدادات", color = PrimaryTextLight)
            }
        }
    }
}
