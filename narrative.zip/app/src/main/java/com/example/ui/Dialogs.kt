package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Part
import com.example.ui.theme.*

@Composable
fun SummaryDialog(part: Part, onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ملخص الجزء", fontWeight = FontWeight.Bold, color = PrimaryTextLight) },
        text = {
            if (part.summary != null) {
                Text(part.summary, color = PrimaryTextLight, lineHeight = 24.sp)
            } else {
                Text("سيتم إنشاء الملخص تلقائيًا عند اكتمال الجزء.", color = SecondaryTextLight)
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                if (part.summary != null) {
                    TextButton(onClick = {
                        val shareIntent = android.content.Intent().apply {
                            action = android.content.Intent.ACTION_SEND
                            type = "text/plain"
                            putExtra(android.content.Intent.EXTRA_TEXT, "ملخص ${part.title}:\n\n${part.summary}")
                        }
                        context.startActivity(android.content.Intent.createChooser(shareIntent, "مشاركة الملخص"))
                    }) {
                        Text("مشاركة", color = AccentColor)
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = onDismiss) {
                    Text("إغلاق", color = AccentColor)
                }
            }
        },
        containerColor = SurfaceLight,
        shape = RoundedCornerShape(16.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDialog(viewModel: NarrativeViewModel, onDismiss: () -> Unit) {
    val messageLimit by viewModel.messageLimit.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()

    var sliderValue by remember { mutableStateOf(messageLimit.toFloat()) }
    var currentApiKey by remember { mutableStateOf(apiKey) }
    var currentSelectedModel by remember { mutableStateOf(selectedModel) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var passwordVisible by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }

    val models = listOf(
        "llama-3.3-70b-versatile" to "Llama 3.3 70B",
        "mixtral-8x7b-32768" to "Mixtral 8x7B",
        "llama-3.1-8b-instant" to "Llama 3.1 8B",
        "gemma2-9b-it" to "Gemma 2 9B"
    )

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = true
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("الإعدادات", fontWeight = FontWeight.Bold, color = PrimaryTextLight) },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(androidx.compose.material.icons.Icons.Default.ArrowBack, contentDescription = "رجوع", tint = PrimaryTextLight)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceLight)
                )
            },
            containerColor = SurfaceLight
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(SurfaceLight)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // API Key Section
                Text("مفتاح API", fontWeight = FontWeight.Bold, color = PrimaryTextLight)
                Spacer(modifier = Modifier.height(8.dp))
                androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Ltr) {
                    OutlinedTextField(
                        value = currentApiKey,
                        onValueChange = { 
                            currentApiKey = it
                            viewModel.setApiKey(it)
                        },
                        placeholder = { Text("أدخل مفتاح API هنا...", color = SecondaryTextLight) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        visualTransformation = if (passwordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Password),
                        trailingIcon = {
                            val image = if (passwordVisible) androidx.compose.material.icons.Icons.Default.Visibility else androidx.compose.material.icons.Icons.Default.VisibilityOff
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(imageVector = image, contentDescription = if (passwordVisible) "إخفاء" else "إظهار", tint = SecondaryTextLight)
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentColor,
                            unfocusedBorderColor = BorderLight,
                            focusedTextColor = PrimaryTextLight,
                            unfocusedTextColor = PrimaryTextLight
                        )
                    )
                }
                Text("مثال: gsk_... أو sk-...", fontSize = 12.sp, color = SecondaryTextLight, modifier = Modifier.padding(top = 4.dp))
                
                Spacer(modifier = Modifier.height(24.dp))

                // Model Selection Section
                Text("النموذج", fontWeight = FontWeight.Bold, color = PrimaryTextLight)
                Spacer(modifier = Modifier.height(8.dp))
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = models.find { it.first == currentSelectedModel }?.second ?: currentSelectedModel,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentColor,
                            unfocusedBorderColor = BorderLight,
                            focusedTextColor = PrimaryTextLight,
                            unfocusedTextColor = PrimaryTextLight
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(SurfaceLight)
                    ) {
                        models.forEach { (value, label) ->
                            DropdownMenuItem(
                                text = { Text(label, color = PrimaryTextLight) },
                                onClick = {
                                    currentSelectedModel = value
                                    viewModel.setSelectedModel(value)
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Message Limit Section
                Text("حد الرسائل لكل جزء", fontWeight = FontWeight.Bold, color = PrimaryTextLight)
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Slider(
                        value = sliderValue,
                        onValueChange = { 
                            sliderValue = it
                            viewModel.setMessageLimit(it.toInt())
                        },
                        valueRange = 10f..50f,
                        steps = 4,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = AccentColor, activeTrackColor = AccentColor)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("${sliderValue.toInt()}", color = PrimaryTextLight, fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(24.dp))
                HorizontalDivider(color = BorderLight)
                Spacer(modifier = Modifier.height(24.dp))

                // Data Section
                Text("البيانات", fontWeight = FontWeight.Bold, color = PrimaryTextLight)
                Spacer(modifier = Modifier.height(8.dp))
                if (showDeleteConfirm) {
                    Text("هل أنت متأكد؟ سيتم حذف جميع المحادثات نهائيًا.", color = Color.Red, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row {
                        Button(
                            onClick = { 
                                viewModel.deleteAllData()
                                showDeleteConfirm = false 
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red, contentColor = Color.White),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("تأكيد الحذف")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = { showDeleteConfirm = false },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SecondaryTextLight),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء")
                        }
                    }
                } else {
                    OutlinedButton(
                        onClick = { showDeleteConfirm = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.Red),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("مسح جميع المحادثات")
                    }
                }

                Spacer(modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.height(32.dp))

                // About Section
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
                ) {
                    Text("ناراتيف", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = PrimaryTextLight)
                    Text("الإصدار 1.0.0", fontSize = 14.sp, color = SecondaryTextLight)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("جميع البيانات محلية على جهازك", fontSize = 12.sp, color = SecondaryTextLight)
                }
            }
        }
    }
}
