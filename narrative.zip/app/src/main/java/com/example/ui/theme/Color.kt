package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundLight = Color(0xFFFAFAFA)
val SurfaceLight = Color(0xFFFFFFFF)
val PrimaryTextLight = Color(0xFF1A1A1A)
val AccentColor = Color(0xFF6B4F4B)
val SecondaryTextLight = Color(0xFF8E8E93)
val BorderLight = Color(0xFFE5E5EA)
val UserBubbleBackground = Color(0xFF1A1A1A)
val UserBubbleText = Color(0xFFFFFFFF)
val AIBubbleBackground = Color(0xFFF2F2F7)
val AIBubbleText = Color(0xFF1A1A1A)
