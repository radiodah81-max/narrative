package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.NarrativeRepository
import com.example.data.SettingsRepository
import com.example.data.model.Message
import com.example.data.model.Part
import com.example.inference.LocalInferenceEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NarrativeViewModel(
    private val repository: NarrativeRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val engine = LocalInferenceEngine()

    val onboardingComplete: StateFlow<Boolean> = settingsRepository.onboardingComplete
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val messageLimit: StateFlow<Int> = settingsRepository.messageLimit
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 20)

    val apiKey: StateFlow<String> = settingsRepository.apiKey
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    val selectedModel: StateFlow<String> = settingsRepository.selectedModel
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "llama-3.1-8b-instant")

    val allParts: StateFlow<List<Part>> = repository.allParts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activePartId = MutableStateFlow<Int?>(null)
    val activePartId: StateFlow<Int?> = _activePartId

    private val _activeMessages = MutableStateFlow<List<Message>>(emptyList())
    val activeMessages: StateFlow<List<Message>> = _activeMessages

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating

    init {
        viewModelScope.launch {
            val lastPart = repository.getLastPart()
            if (lastPart == null) {
                val newId = repository.insertPart(Part(number = 1, title = "الجزء 1"))
                _activePartId.value = newId
            } else {
                _activePartId.value = lastPart.id
            }

            _activePartId.collect { partId ->
                if (partId != null) {
                    repository.getMessagesForPart(partId).collect { msgs ->
                        _activeMessages.value = msgs
                    }
                }
            }
        }
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            settingsRepository.setOnboardingComplete(true)
        }
    }

    fun setMessageLimit(limit: Int) {
        viewModelScope.launch {
            settingsRepository.setMessageLimit(limit)
        }
    }

    fun setApiKey(key: String) {
        viewModelScope.launch {
            settingsRepository.setApiKey(key)
        }
    }

    fun setSelectedModel(model: String) {
        viewModelScope.launch {
            settingsRepository.setSelectedModel(model)
        }
    }

    fun selectPart(partId: Int) {
        _activePartId.value = partId
    }

    fun createNewPartManually() {
        viewModelScope.launch {
            val currentParts = allParts.value
            val nextNumber = (currentParts.maxOfOrNull { it.number } ?: 0) + 1
            val newId = repository.insertPart(Part(number = nextNumber, title = "الجزء \$nextNumber"))
            _activePartId.value = newId
        }
    }

    fun sendMessage(content: String) {
        val partId = _activePartId.value ?: return
        val currentLimit = messageLimit.value
        
        viewModelScope.launch {
            _isGenerating.value = true
            
            // 1. Insert user message
            repository.insertMessage(Message(partId = partId, role = "user", content = content))
            
            // 2. Check if we reached the limit
            val visibleMsgs = repository.getVisibleMessagesForPartSync(partId)
            
            if (visibleMsgs.size >= currentLimit) {
                // Time to chunk and summarize
                val currentPart = repository.getPartById(partId)
                if (currentPart != null) {
                    val messagesToSummarize = visibleMsgs.map { it.role + ": " + it.content }
                    val summary = engine.summarizeConversation(messagesToSummarize)
                    
                    // Update old part
                    repository.updatePart(currentPart.copy(summary = summary))
                    
                    // Create new part
                    val nextNumber = currentPart.number + 1
                    val newPartId = repository.insertPart(Part(number = nextNumber, title = "الجزء \$nextNumber"))
                    
                    // Add summary as hidden system message in new part
                    repository.insertMessage(
                        Message(partId = newPartId, role = "system", content = summary, isHidden = true)
                    )
                    
                    _activePartId.value = newPartId
                    
                    // Generate AI response in the NEW part context
                    val response = engine.generateResponse(content, listOf(summary))
                    repository.insertMessage(Message(partId = newPartId, role = "ai", content = response))
                }
            } else {
                // Normal flow
                val history = visibleMsgs.map { it.content }
                val response = engine.generateResponse(content, history)
                repository.insertMessage(Message(partId = partId, role = "ai", content = response))
            }
            
            _isGenerating.value = false
        }
    }

    fun deletePart(id: Int) {
        viewModelScope.launch {
            repository.deletePartById(id)
            if (_activePartId.value == id) {
                val latest = repository.getLastPart()
                if (latest != null) {
                    _activePartId.value = latest.id
                } else {
                    val newId = repository.insertPart(Part(number = 1, title = "الجزء 1"))
                    _activePartId.value = newId
                }
            }
        }
    }

    fun deleteAllData() {
        viewModelScope.launch {
            repository.deleteAllData()
            val newId = repository.insertPart(Part(number = 1, title = "الجزء 1"))
            _activePartId.value = newId
        }
    }

    suspend fun getStats(): Pair<Int, Int> {
        return repository.getTotalStats()
    }
}
