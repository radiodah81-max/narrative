package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Message
import com.example.data.model.Part
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: NarrativeViewModel) {
    val activePartId by viewModel.activePartId.collectAsState()
    val allParts by viewModel.allParts.collectAsState()
    val messages by viewModel.activeMessages.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val messageLimit by viewModel.messageLimit.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showSummaryDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val activePart = allParts.find { it.id == activePartId }
    val visibleMessages = messages.filter { !it.isHidden }
    val listState = rememberLazyListState()

    LaunchedEffect(visibleMessages.size, isGenerating) {
        if (visibleMessages.isNotEmpty()) {
            listState.animateScrollToItem(visibleMessages.size - 1)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            SidebarContent(
                parts = allParts,
                activePartId = activePartId,
                onPartSelect = { id ->
                    viewModel.selectPart(id)
                    scope.launch { drawerState.close() }
                },
                onNewPartClick = {
                    viewModel.createNewPartManually()
                    scope.launch { drawerState.close() }
                },
                onSettingsClick = {
                    showSettingsDialog = true
                    scope.launch { drawerState.close() }
                }
            )
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = activePart?.title ?: "محادثة جديدة",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = PrimaryTextLight
                            )
                            Text(
                                text = "الجزء الحالي",
                                fontSize = 12.sp,
                                color = SecondaryTextLight
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "القائمة", tint = PrimaryTextLight)
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.createNewPartManually() }) {
                            Icon(Icons.Default.Add, contentDescription = "جزء جديد", tint = PrimaryTextLight)
                        }
                        IconButton(onClick = { showSummaryDialog = true }) {
                            Icon(Icons.Default.Bookmark, contentDescription = "الملخص", tint = if (activePart?.summary != null) AccentColor else SecondaryTextLight)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceLight)
                )
            },
            bottomBar = {
                ChatInputArea(
                    isGenerating = isGenerating,
                    messageCount = visibleMessages.size,
                    messageLimit = messageLimit,
                    onSend = { content -> viewModel.sendMessage(content) }
                )
            },
            containerColor = BackgroundLight
        ) { paddingValues ->
            Box(modifier = Modifier.padding(paddingValues).fillMaxSize()) {
                if (visibleMessages.isEmpty() && !isGenerating) {
                    EmptyChatState()
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(visibleMessages) { msg ->
                            MessageBubble(message = msg)
                        }
                        if (isGenerating) {
                            item {
                                TypingIndicator()
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSummaryDialog && activePart != null) {
        SummaryDialog(part = activePart, onDismiss = { showSummaryDialog = false })
    }

    if (showSettingsDialog) {
        SettingsDialog(viewModel = viewModel, onDismiss = { showSettingsDialog = false })
    }
}
