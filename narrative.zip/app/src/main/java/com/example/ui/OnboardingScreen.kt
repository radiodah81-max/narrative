package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentColor
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.PrimaryTextLight
import com.example.ui.theme.SecondaryTextLight
import com.example.ui.theme.SurfaceLight
import kotlinx.coroutines.launch

@Composable
fun OnboardingScreen(onComplete: () -> Unit) {
    val pagerState = rememberPagerState(pageCount = { 3 })
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f)
        ) { page ->
            when (page) {
                0 -> OnboardingPage(
                    icon = Icons.Default.Layers,
                    title = "محادثات لا تنتهي",
                    description = "نظام الأجزاء الذكي يقوم بتلخيص السياق وإنشاء أجزاء جديدة تلقائياً لتجاوز حدود الذاكرة المعتادة.",
                    onStartClick = { coroutineScope.launch { pagerState.animateScrollToPage(1) } }
                )
                1 -> OnboardingPage(
                    icon = Icons.Default.Lock,
                    title = "خصوصية تامة",
                    description = "كل شيء يعمل على جهازك بالكامل. لا حاجة للإنترنت ولا توجد خوادم خارجية تحتفظ ببياناتك.",
                    onStartClick = { coroutineScope.launch { pagerState.animateScrollToPage(2) } }
                )
                2 -> OnboardingPage(
                    icon = Icons.Default.AutoAwesome,
                    title = "مساعدك الشخصي",
                    description = "نماذج ذكاء اصطناعي مدمجة جاهزة للإجابة والمساعدة في أي وقت وبسرية تامة.",
                    isLast = true,
                    onStartClick = onComplete
                )
            }
        }
    }
}

@Composable
fun OnboardingPage(
    icon: ImageVector,
    title: String,
    description: String,
    isLast: Boolean = false,
    onStartClick: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = AccentColor,
            modifier = Modifier.size(80.dp)
        )
        Spacer(modifier = Modifier.height(40.dp))
        Text(
            text = title,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = PrimaryTextLight
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = description,
            fontSize = 16.sp,
            color = SecondaryTextLight,
            textAlign = TextAlign.Center,
            lineHeight = 24.sp
        )
        
        Spacer(modifier = Modifier.height(60.dp))
        Button(
            onClick = onStartClick,
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor, contentColor = SurfaceLight),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Text(if (isLast) "ابدأ الآن" else "التالي", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}
