package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.data.NarrativeRepository
import com.example.data.SettingsRepository
import com.example.ui.AppNavigation
import com.example.ui.NarrativeViewModel
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    val database = AppDatabase.getDatabase(this)
    val repository = NarrativeRepository(database.partDao(), database.messageDao())
    val settingsRepository = SettingsRepository(this)
    
    val factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NarrativeViewModel(repository, settingsRepository) as T
        }
    }

    setContent {
      MyApplicationTheme {
        val viewModel: NarrativeViewModel = viewModel(factory = factory)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AppNavigation(viewModel = viewModel)
        }
      }
    }
  }
}

