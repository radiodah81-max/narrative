package com.example.inference

import kotlinx.coroutines.delay

class LocalInferenceEngine {

    /**
     * Simulates generating a chat response purely locally.
     * In a production fully local setup, this would be replaced by MediaPipe GenAI 
     * (e.g., Llama 3 8B or Gemma 2B) running entirely on-device via a downloaded `.bin`/`.task` model file.
     */
    suspend fun generateResponse(prompt: String, context: List<String>): String {
        // Simulate local processing delay
        delay(1200)

        val lowerPrompt = prompt.lowercase()
        return when {
            lowerPrompt.contains("مرحبا") || lowerPrompt.contains("أهلا") ->
                "أهلاً بك في ناراتيف! كيف يمكنني مساعدتك اليوم؟"
            lowerPrompt.contains("شكرا") ->
                "على الرحب والسعة! هل هناك شيء آخر يمكنني المساعدة به؟"
            lowerPrompt.contains("قصه") || lowerPrompt.contains("قصة") ->
                "في مدينة هادئة بين الجبال، عاش هناك طائر غريب يمتلك ريشاً يضيء في الظلام. كان الطائر يظهر فقط عندما يحتاج شخص ما إلى بصيص من الأمل..."
            lowerPrompt.contains("شرح") ->
                "بالتأكيد. الفكرة هنا هي تبسيط الأمور المعقدة إلى أجزاء صغيرة يسهل فهمها وتذكرها."
            lowerPrompt.contains("تخطيط") ->
                "إليك خطة بسيطة: \n1. تحديد الأهداف الأساسية\n2. تقسيم المهام\n3. التنفيذ المجدول\n4. المراجعة والتحسين"
            else -> 
                "لقد فهمت رسالتك: '$prompt'. أنا هنا كمساعد محلي بالكامل لضمان خصوصيتك. يمكنك سؤالي عن أي موضوع!"
        }
    }

    /**
     * Simulates summarizing a conversation.
     * In reality, this feeds the last N messages to the LLM and asks for a short summary.
     */
    suspend fun summarizeConversation(messages: List<String>): String {
        // Simulate local summarization delay
        delay(1500)
        
        if (messages.isEmpty()) return "محادثة فارغة."
        
        return "هذا ملخص لما سبق: المستخدم والمساعد تبادلا أطراف الحديث حول عدة مواضيع. " +
               "تضمنت المحادثة ${messages.size} رسالة، وتم حفظ السياق بنجاح للجزء التالي من المحادثة."
    }
}
