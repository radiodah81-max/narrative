package com.example.data

import com.example.data.dao.MessageDao
import com.example.data.dao.PartDao
import com.example.data.model.Message
import com.example.data.model.Part
import kotlinx.coroutines.flow.Flow

class NarrativeRepository(
    private val partDao: PartDao,
    private val messageDao: MessageDao
) {
    val allParts: Flow<List<Part>> = partDao.getAllParts()

    suspend fun getLastPart(): Part? = partDao.getLastPart()

    suspend fun getPartById(id: Int): Part? = partDao.getPartById(id)

    suspend fun insertPart(part: Part): Int = partDao.insertPart(part).toInt()

    suspend fun updatePart(part: Part) = partDao.updatePart(part)

    suspend fun deletePartById(id: Int) = partDao.deletePartById(id)

    suspend fun deleteAllData() = partDao.deleteAllParts()

    fun getMessagesForPart(partId: Int): Flow<List<Message>> = messageDao.getMessagesForPart(partId)

    suspend fun getVisibleMessagesForPartSync(partId: Int): List<Message> = messageDao.getVisibleMessagesForPartSync(partId)

    fun getVisibleMessageCount(partId: Int): Flow<Int> = messageDao.getVisibleMessageCount(partId)

    suspend fun insertMessage(message: Message) = messageDao.insertMessage(message)

    suspend fun getTotalStats(): Pair<Int, Int> {
        val parts = partDao.getPartCount()
        val messages = messageDao.getTotalMessageCount()
        return Pair(parts, messages)
    }
}
