package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.Message
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE partId = :partId ORDER BY timestamp ASC")
    fun getMessagesForPart(partId: Int): Flow<List<Message>>

    @Query("SELECT * FROM messages WHERE partId = :partId AND isHidden = 0 ORDER BY timestamp ASC")
    suspend fun getVisibleMessagesForPartSync(partId: Int): List<Message>

    @Query("SELECT COUNT(*) FROM messages WHERE partId = :partId AND isHidden = 0")
    fun getVisibleMessageCount(partId: Int): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: Message)

    @Query("DELETE FROM messages WHERE partId = :partId")
    suspend fun deleteMessagesByPartId(partId: Int)

    @Query("SELECT COUNT(*) FROM messages")
    suspend fun getTotalMessageCount(): Int
}
