package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Part
import kotlinx.coroutines.flow.Flow

@Dao
interface PartDao {
    @Query("SELECT * FROM parts ORDER BY createdAt DESC")
    fun getAllParts(): Flow<List<Part>>

    @Query("SELECT * FROM parts WHERE id = :id")
    suspend fun getPartById(id: Int): Part?

    @Query("SELECT * FROM parts ORDER BY number DESC LIMIT 1")
    suspend fun getLastPart(): Part?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPart(part: Part): Long

    @Update
    suspend fun updatePart(part: Part)

    @Query("DELETE FROM parts WHERE id = :id")
    suspend fun deletePartById(id: Int)

    @Query("DELETE FROM parts")
    suspend fun deleteAllParts()
    
    @Query("SELECT COUNT(*) FROM parts")
    suspend fun getPartCount(): Int
}
