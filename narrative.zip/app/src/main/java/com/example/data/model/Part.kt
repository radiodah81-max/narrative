package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "parts")
data class Part(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val number: Int,
    val title: String,
    val summary: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
